/** Automatically generated file. DO NOT MODIFY */
package com.todddavies.components.progressbar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}